# 🧭 Inner Compass – AI Decision Assistant

A natural language processing tool to support reflective decision-making using emotion and motivation analysis.

## 🔧 Built With
- Python
- Streamlit
- TextBlob

## 💡 Features
- AI-based sentiment and subjectivity analysis
- Internal vs external motivation detection
- Bias word detection (e.g., “should”, “must”)
- Real-time personalized advice
- Clean and calming UI design (no images required)

## 🚀 How to Run
```bash
pip install -r requirements.txt
python -m textblob.download_corpora
streamlit run app.py
