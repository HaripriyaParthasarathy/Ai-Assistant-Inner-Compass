import streamlit as st
from textblob import TextBlob
import random

# ---------- Custom CSS Styling ----------
st.markdown(
    """
    <style>
    body {
        background: linear-gradient(to right, #dfe9f3, #ffffff);
    }
    .stApp {
        background: linear-gradient(to right, #dfe9f3, #ffffff);
        font-family: 'Segoe UI', sans-serif;
        padding: 2rem;
    }
    h1, h2 {
        color: #1f4e79;
    }
    .stButton>button {
        background-color: #1f4e79;
        color: white;
        font-weight: bold;
        border-radius: 8px;
        padding: 0.5rem 1rem;
    }
    textarea, input {
        background-color: #f0f7ff !important;
        color: #000000 !important;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# ---------- Page Title ----------
st.title("🧭 Inner Compass – AI Decision Assistant")
st.write("Gain clarity using natural language processing and personalized emotional analysis.")

# ---------- User Input ----------
decision = st.text_input("📝 What's the decision you're trying to make?")
thoughts = st.text_area("💬 Write your thoughts and feelings about this decision:")

if st.button("Get AI Guidance"):
    if not thoughts:
        st.warning("Please share your thoughts for analysis.")
    else:
        # ---------- NLP Analysis ----------
        blob = TextBlob(thoughts)
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity

        # Motivation Detection
        internal_keywords = ["i want", "i need", "i feel", "i believe"]
        external_keywords = ["they want", "others think", "people say", "i was told"]

        internal_count = sum(1 for kw in internal_keywords if kw in thoughts.lower())
        external_count = sum(1 for kw in external_keywords if kw in thoughts.lower())

        # Bias Detection (simple version)
        bias_detected = any(bias in thoughts.lower() for bias in ["should", "must", "always", "never"])

        # ---------- Dynamic Advice Logic ----------
        advice = ""

        if polarity < -0.2:
            advice += "😟 You seem to be feeling negatively. Give yourself some space and revisit this decision later.\n\n"
        elif polarity > 0.2:
            advice += "😊 You sound optimistic. Trust your gut, but double-check practical facts.\n\n"
        else:
            advice += "😐 You're emotionally unclear. Try journaling or discussing with someone you trust.\n\n"

        if internal_count > external_count:
            advice += "💡 This decision feels internally motivated. Reflect on whether it aligns with your long-term values.\n\n"
        elif external_count > internal_count:
            advice += "🔎 You might be influenced by others. Consider what *you* really want.\n\n"
        else:
            advice += "🤔 Try clarifying whether this decision is based on your own needs or external pressure.\n\n"

        if bias_detected:
            advice += "⚠️ Words like 'should' or 'must' may point to hidden beliefs or obligations.\n\n"

        # Extra encouragement
        encouragement = random.choice([
            "You’ve got this! 💪",
            "Clarity comes with reflection. 🌱",
            "Every decision is a chance to grow. 🌟",
            "Breathe deep. The right choice will come. 🧘"
        ])
        advice += f"**{encouragement}**"

        # ---------- Show Results ----------
        st.subheader("🧠 AI-Powered Insight")
        st.success(advice)
