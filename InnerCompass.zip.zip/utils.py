from textblob import TextBlob
from transformers import pipeline

try:
    emotion_model = pipeline("text-classification", model="distilbert-base-uncased-finetuned-sst-2-english")
except Exception as e:
    print("🔥 Error loading emotion model:", e)
    emotion_model = None

def analyze_decision(dilemma, thoughts):
    blob = TextBlob(thoughts)
    polarity = blob.sentiment.polarity
    sentiment = "Positive" if polarity > 0 else "Negative" if polarity < 0 else "Neutral"

    if emotion_model:
        emotion_result = emotion_model(thoughts)[0]
        emotion_label = emotion_result['label']
        emotion_score = emotion_result['score']
    else:
        emotion_label = "Unknown"
        emotion_score = 0.5

    motivation = "Internal" if "I want" in thoughts or "I feel" in thoughts else "External"

    bias_words = ["scared", "afraid", "risk", "fail"]
    bias = "Fear-Based" if any(word in thoughts.lower() for word in bias_words) else "Balanced"

    clarity_score = int((abs(polarity) + emotion_score) * 50)

    if clarity_score < 50:
        advice = "You seem emotionally unclear. Try journaling your values or talking to a mentor."
    elif bias == "Fear-Based":
        advice = "Your fear might be clouding your clarity. Try reframing the worst-case scenario."
    elif motivation == "External":
        advice = "You're driven by external pressure. Reflect if this aligns with what you truly want."
    else:
        advice = "You're reasonably clear. It might be time to act, even if it feels scary."

    return {
        "sentiment": sentiment,
        "motivation": motivation,
        "bias": bias,
        "clarity_score": clarity_score,
        "advice": advice
    }
